# Silver the Hedgehog + Telekinesis for Vampire Survivors

Play (almost) any survivor as a Silver-inspired psychic mage with an innate
Telekinesis weapon: grab the nearest enemy, carry it as a burning bubble-bomb,
then fling it into the crowd where it detonates. Built and balanced through
30+ in-game test iterations. Single-player/offline only.

**Fan work, not affiliated.** Silver the Hedgehog is SEGA's character (Sonic
the Hedgehog 2006). All sprites and sounds here are original fan-made
placeholders. Vampire Survivors belongs to poncle. Built with AI assistance;
every release was play-tested in-game before publishing.

## What it does

- **Silver kit** (applies to the character you pick): +15% Duration to start,
  +5% more at levels 5/10/15/20/25, +20% Growth, +20% Luck, 0.9x move speed,
  psychic beacon (+Curse/+Might). Hover-bob visuals with the fan sprite set.
- **Telekinesis** (innate, active from run start, levels 1-8 through its own
  level-up cards): grabs nearby enemies, yanks them to Silver's side, carries
  them while they burn what they touch, then flings them toward your facing
  for impact damage. Stand still to throw early. Scales with Might, Area,
  Amount, Duration and Cooldown like a real weapon.
- Grip ring, green captive bubble, positional grab/throw/impact sounds.
  Everything tunable in the config file.

## Install (Steam, Windows)

1. Install BepInEx 6 bleeding-edge IL2CPP (`Unity.IL2CPP-win-x64`,
   build 6.0.0-be.788 or newer from builds.bepinex.dev) into your Vampire
   Survivors folder (the one with `VampireSurvivors.exe`). Run the game once
   (first start is slow: it builds compatibility files), then quit.
2. Copy `SilverTelekinesis.dll`, `frames/`, `tk_glow.png`, `tk_hands.png`,
   `tk_orb.png` and `sfx/` into `<game>/BepInEx/plugins/SilverTelekinesis/`.
3. Launch and start any offline/single-player run. Do NOT use in online co-op.

## Tune it

Open `<game>/BepInEx/config/you.silverdtelekinesis.cfg` after the first run:
`[Silver]` for the stat kit, `[Telekinesis]` for ranges/damage/timings,
`[TelekinesisFX]` for visuals and volume. Edits apply live mid-run.

## Uninstall

Delete `<game>/BepInEx/plugins/SilverTelekinesis/`. Saves are untouched
(the mod never writes to them).

## Credits

- BepInEx, HarmonyX, Il2CppInterop, Cpp2IL, ILSpy teams
- OffTheClockMods/vampiresurvivors-mods and kulmin/VSEvolutionHelperEx for
  the proven BepInEx-6-on-Unity-6 patterns this mod builds on
- poncle for Vampire Survivors; SEGA/Sonic Team for Silver's inspiration
